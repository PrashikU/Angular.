import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'wraptext'
})
// export class WraptextPipe implements PipeTransform {

//   transform(value: unknown, ...args: unknown[]): unknown {
//     return null;
//   }

// }
export class WraptextPipe implements PipeTransform {
  transform(value: string, numWords: number): string {
    if (!value) return value;
    let words = value.split('');
    if (words.length > numWords) {
      return words.slice(0, numWords).join('') + '...';
    }
    return value;
  }
}
