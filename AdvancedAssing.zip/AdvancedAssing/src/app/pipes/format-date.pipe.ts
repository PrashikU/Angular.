import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatDate'
})
// export class FormatDatePipe implements PipeTransform {

//   transform(value: unknown, ...args: unknown[]): unknown {
//     return null;
//   }

// }

export class FormatDatePipe implements PipeTransform {
  transform(value: string, formatType: string): string {
    const date = new Date(value);
    if (formatType === 'short-date') {
      return `${date.getDate()} ${date.toLocaleString('default', { month: 'short' })} ${date.getFullYear()}`;
    } else if (formatType === 'short-time') {
      return `${date.getHours()}:${date.getMinutes()}`;
    }
    return value;
  }
}
