import { WraptextPipe } from './wraptext.pipe';

describe('WraptextPipe', () => {
  it('create an instance', () => {
    const pipe = new WraptextPipe();
    expect(pipe).toBeTruthy();
  });
});
