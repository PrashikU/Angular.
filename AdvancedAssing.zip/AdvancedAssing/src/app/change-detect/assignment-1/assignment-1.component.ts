
import { Component } from '@angular/core';

@Component({
  selector: 'app-assignment-1',
  templateUrl: './assignment-1.component.html',
  styleUrl: './assignment-1.component.scss'
})
export class Assignment1Component {

}
