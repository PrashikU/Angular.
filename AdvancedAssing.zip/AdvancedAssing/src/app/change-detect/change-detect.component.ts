// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-change-detect',
//   templateUrl: './change-detect.component.html',
//   styleUrl: './change-detect.component.scss'
// })
// export class ChangeDetectComponent {

// }

import { Component ,ChangeDetectionStrategy} from '@angular/core';
import { Bulletin } from './bulletin';
// import { Bulletin } from '../bulletin';
Bulletin


@Component({
  selector: 'app-change-detect',
  templateUrl: './change-detect.component.html',
  styleUrl: './change-detect.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush // Use OnPush strategy

})
export class ChangeDetectComponent {
  bulletinDefault: Bulletin;
  bulletinOnPush: Bulletin;

  constructor() {
    this.bulletinDefault = new Bulletin("Default Title", "Default Date");
    this.bulletinOnPush = new Bulletin("OnPush Title", "OnPush Date");
  }

  changeDetectionDefault() {
    this.bulletinDefault.news_title = "Updated Default Title";
    this.bulletinDefault.news_date = "Updated Default Date";
  }

  changeDetectionOnPush() {
    this.bulletinOnPush.news_title = "Updated OnPush Title";
    this.bulletinOnPush.news_date = "Updated OnPush Date";
  }
}
