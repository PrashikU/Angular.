export class Bulletin{

    constructor(public news_title: string, public news_date: string) {}

}