

import { Component } from '@angular/core';
import { RegistrationService } from '../../Service/registration.service';


RegistrationService
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrl: './registration.component.scss'
})
export class RegistrationComponent {
  
  successMessage: string = '';
  errorMessage: string = '';
  email:any;
  password:any;

  constructor(
   
    private registrationService: RegistrationService
  ) {
 
  }

  onSubmit() {
   
      
      this.registrationService.registerUser(this.email, this.password).subscribe({
        next: (response) => {
          localStorage.setItem('token', response.token);
          this.successMessage = 'Registration successful!';
          console.log("Response:",response)
          this.errorMessage = '';
        },
        error: (error) => {
          this.successMessage = '';
          this.errorMessage = 'Registration failed. Please try again.';
        }
      });
    }
  }

