import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing8Component } from './assing8.component';

describe('Assing8Component', () => {
  let component: Assing8Component;
  let fixture: ComponentFixture<Assing8Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing8Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing8Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
