import { Component, OnInit } from '@angular/core';
import { UserService } from '../Service/user.service';

@Component({
  selector: 'app-assing8',
  templateUrl: './assing8.component.html',
  styleUrl: './assing8.component.scss'
})
export class Assing8Component implements OnInit {

  output:any
  users:any
  singleUserData:any
  singleUser:any
  singleId:any
  
  flag=false
  constructor(private api: UserService) { 
  }
  
  
  ngOnInit(): void {
    this.userListCollector();

  
  }
  
  editUser(user: any) {
    user.isEditing = true;
  }
  saveUser(user: any) {
    user.isEditing = false;
    this.postUserUpdator(user)
  }
  cancelEdit(user: any) {
    user.isEditing = false;
  }
  closeDetails() {
    this.flag = false;
  }
  
  
  public userListCollector(): any {
    this.api.getUserList("users?page=1").subscribe(
      res => {
        this.output = res; 
        this.users = this.output.data;   
        });
  }
  
  public singleUserCollector(singleId:any): any {
    this.api.getSingleUser("users", singleId).subscribe(
      res => {
        
        this.singleUserData = res;
        this.singleUser = this.singleUserData.data;
        this.flag=true
        console.log(this.singleUser) 
        });
  }
  
  public postUserUpdator(object:any): any {
    this.api.postUser("users",object).subscribe(             //add onject at formal args
      res => {
        this.output = res;
        console.log(this.output);
      });
  }
  
  public deletUserUpdator(id:any): any {
    this.api.deletUser("users",id).subscribe(             //add onject at formal args
      res => {
        this.output = res;
        console.log(this.output);
        alert("user is deleted")
      });
  }
  
  }
  