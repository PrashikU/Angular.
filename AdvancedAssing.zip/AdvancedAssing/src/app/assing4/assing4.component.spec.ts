import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing4Component } from './assing4.component';

describe('Assing4Component', () => {
  let component: Assing4Component;
  let fixture: ComponentFixture<Assing4Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing4Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
