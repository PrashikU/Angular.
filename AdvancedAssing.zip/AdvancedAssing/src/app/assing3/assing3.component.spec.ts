import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing3Component } from './assing3.component';

describe('Assing3Component', () => {
  let component: Assing3Component;
  let fixture: ComponentFixture<Assing3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing3Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
