import { Component } from '@angular/core';
import { WraptextPipe } from '../pipes/wraptext.pipe';
import { FormatDatePipe } from '../pipes/format-date.pipe';
FormatDatePipe
WraptextPipe

@Component({
  selector: 'app-assing3',
  templateUrl: './assing3.component.html',
  styleUrl: './assing3.component.scss'
})
export class Assing3Component {
  news = {
    news_title: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. ',
    news_date: '2023-06-10T14:20:00Z'
  };

}
