import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
AppComponent
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { WraptextPipe } from './pipes/wraptext.pipe';
import { FormatDatePipe } from './pipes/format-date.pipe';
import { Assing3Component } from './assing3/assing3.component';
import { FormsModule } from '@angular/forms';
UserService
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { MatBadgeModule } from '@angular/material/badge';

import { MatDialogModule } from '@angular/material/dialog';
import { MatSelectModule } from '@angular/material/select';

import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatTableModule} from '@angular/material/table';
import { MatError } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';


import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatListModule } from '@angular/material/list';




import { BackgroundComponent } from './background/background.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { HttpClientModule, provideHttpClient, withFetch } from '@angular/common/http';



import { Assing8Component } from './assing8/assing8.component';
import { UserService } from './Service/user.service';
import { RegistrationComponent } from './assing7/registration/registration.component';
import { ChangeDetectComponent } from './change-detect/change-detect.component';
import { Assignment1Component } from './change-detect/assignment-1/assignment-1.component';
import { LiveNewsComponentComponent } from './assing2/live-news.component/live-news.component.component';
import { Assing4Component } from './assing4/assing4.component';
import { HighlightNewsTitleDirective } from './assing4/highlight-news-title.directive';
import { Assing5Component } from './assing5/assing5.component';


import {MatChipsModule} from '@angular/material/chips';
import {MatDatepickerModule} from '@angular/material/datepicker';
// import { DialogComponent } from './assing13/dialog/dialog.component';
// import {MatDialogModule} from '@angular/material/dialog';
import {MatStepperModule} from '@angular/material/stepper';
import { Assing13Component } from './assing13/assing13.component';
Assing8Component

FormsModule

HttpClientModule
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    WraptextPipe,
    FormatDatePipe,
    HighlightNewsTitleDirective,
    Assing3Component,
  
    BackgroundComponent,
       Assing8Component,
       RegistrationComponent,
       ChangeDetectComponent,
       Assignment1Component,
       LiveNewsComponentComponent,
       Assing4Component,
       HighlightNewsTitleDirective,
       Assing5Component,
       Assing13Component,
  
   
     
     
     
       
      
      
      
    
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    FormsModule,
    MatTabsModule,
    MatIconModule,
    MatBadgeModule,
    MatDialogModule,
    MatSelectModule,
    MatButtonToggleModule,
    MatTableModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    MatCardModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatError,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatStepperModule

    
    
    
  ],
  providers: [
 
    provideHttpClient(withFetch()),
    provideClientHydration(),
    provideAnimationsAsync(),
   
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
