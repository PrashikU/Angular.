
import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Observable, catchError, map, tap } from 'rxjs';

const API_URL = 'https://reqres.in'; 

@Injectable({
  providedIn: 'root'
})
export class UserService implements OnInit{


  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    
  }

  public getUserList(url: string): Observable<any> {
    return this.http.get(API_URL + "/api/" + url).pipe(
      map(res => res),
      tap(() => alert('User list fetched successfully!')),
      catchError(error => {
        alert('Failed to fetch user list!');
        throw error;
      })
    );
  }


public getSingleUser(url: string, userId: string): Observable<any> {
  return this.http.get(API_URL + "/api/" + url + "/" + userId).pipe(
    map(res => res),
    tap(() => alert('User fetched successfully!')),
    catchError(error => {
      alert('Failed to fetch user!');
      throw error;
    })
  );
}
  

 
  public postUser(url: string, tempObj: any): Observable<any> {
    return this.http.post(API_URL + "/api/" + url, tempObj).pipe(
      map(res => res),
      tap(() => alert('User posted successfully!')),
      catchError(error => {
        alert('Failed to post user!');
        throw error;
      })
    );
  }

  public deletUser(url: string, tempObj:any): Observable <any> 
  {
    console.log(API_URL+"/api/"+url)
  
     return this.http.delete(API_URL+"/api/"+url + tempObj).pipe(map(res=>res));
  }

}

