// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class BulletinServiceService {

//   constructor() { }
// }

import { Injectable } from '@angular/core';
// import { Bulletin } from './assignment-1/bulletin';
import { Bulletin } from '../change-detect/bulletin';


@Injectable({
  providedIn: 'root'
})
export class BulletinServiceService {


  //  bulletins: Bulletin[] = [
  //   new Bulletin("News 1", "2024-06-11"),
  //   new Bulletin("News 2", "2024-06-10"),
  //   new Bulletin("News 3", "2024-06-09")
  // ];

  bulletins = 
  [
    {news_title:'News 1',news_date:"2024-06-11"},
    {news_title:"News 2",news_date:"2024-06-10"},
    {news_title:"News 3",news_date:"2024-06-09"},

  ]
  constructor() { }

  getBulletins(): Bulletin[] {
    return this.bulletins;
  }
}