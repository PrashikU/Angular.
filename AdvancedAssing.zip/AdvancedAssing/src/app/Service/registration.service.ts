import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

interface RegistrationResponse {
  token: string;
}

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {
  private apiUrl = 'https://reqres.in/api/register';

  constructor(private http: HttpClient) { }

  registerUser(email: string, password: string): Observable<RegistrationResponse> {
    return this.http.post<RegistrationResponse>(this.apiUrl, { email, password });
  }
}
  