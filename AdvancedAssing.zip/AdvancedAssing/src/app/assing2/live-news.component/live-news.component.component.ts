// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-live-news.component',
//   templateUrl: './live-news.component.component.html',
//   styleUrl: './live-news.component.component.scss'
// })
// export class LiveNewsComponentComponent {

// }
import { Component } from '@angular/core';
import { BulletinServiceService } from '../../Service/bulletin-service.service';
import { Bulletin } from '../../change-detect/bulletin';
// import { Bulletin } from '../../assignment-1/bulletin';
// import { BulletinServiceService } from '../../bulletin-service.service';
// import { delay } from 'rxjs';
BulletinServiceService
Bulletin

@Component({
  selector: 'app-live-news.component',
  templateUrl: './live-news.component.component.html',
  styleUrl: './live-news.component.component.scss'
})
export class LiveNewsComponentComponent  {
  bulletins :any;
  currentBulletinIndex = 0;
  title_news:any;
  date_news:any;

  delay = (ms: number) => new Promise(res => setTimeout(res, ms));

  async get_values(){
    for(let i=0;i<3;i++)
      {
        this.title_news=this.bulletins[i].news_title;
        this.date_news=this.bulletins[i].news_date;
        await this.delay(1000);      }
  }


  constructor(private bulletinService: BulletinServiceService) { 
    this.bulletins = this.bulletinService.bulletins;
    this.get_values();


  }

  ngOnInit(): void {
    // this.startBulletinCycle();
  }

 
 

}