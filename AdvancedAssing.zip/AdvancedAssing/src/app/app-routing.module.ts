import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { Assing3Component } from './assing3/assing3.component';
import { BackgroundComponent } from './background/background.component';
import { Assing8Component } from './assing8/assing8.component';
import { RegistrationComponent } from './assing7/registration/registration.component';
import path from 'path';
import { Assignment1Component } from './change-detect/assignment-1/assignment-1.component';
import { LiveNewsComponentComponent } from './assing2/live-news.component/live-news.component.component';
import { Assing4Component } from './assing4/assing4.component';
import { Assing5Component } from './assing5/assing5.component';
import { Assing13Component } from './assing13/assing13.component';


const routes: Routes = [
  
  {path:'',component:BackgroundComponent},
  {path:'assing1',component:Assignment1Component},
  {path:'assing2',component:LiveNewsComponentComponent},
  {path:'assing3',component:Assing3Component},
  {path:'assing4',component:Assing4Component},
  {path:'assing5',component:Assing5Component},
  {path:'assing7',component:RegistrationComponent},
  {path:'assing8',component:Assing8Component},
  {path:'assing13',component:Assing13Component}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
