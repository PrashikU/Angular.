// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-assing5',
//   templateUrl: './assing5.component.html',
//   styleUrl: './assing5.component.scss'
// })
// export class Assing5Component {

// }


import { Component, OnInit } from '@angular/core';

interface Customer {
  firstName: string;
  lastName: string;
  email: string;
  dob: string;
  mobile: string;
  address?: string;
  pincode: string;
}
@Component({
  selector: 'app-assing5',
  templateUrl: './assing5.component.html',
   styleUrl: './assing5.component.scss'
})
export class Assing5Component implements OnInit {
  customer: Customer = {
    firstName: '',
    lastName: '',
    email: '',
    dob: '',
    mobile: '',
    address: '',
    pincode: ''
  };

  age: number = 0;

  constructor() { }

  ngOnInit(): void {
  }

  calculateAge() {
    const today = new Date();
    const dob = new Date(this.customer.dob);
    this.age = today.getFullYear() - dob.getFullYear();
    const monthDiff = today.getMonth() - dob.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
      this.age--;
    }
  }

  onSubmit(form: any) {
    if (form.valid && this.age >= 18) {
      console.log('Form submitted successfully:', this.customer);
      // Save to localStorage
      const customers = JSON.parse(localStorage.getItem('customers') || '[]');
      customers.push(this.customer);
      localStorage.setItem('customers', JSON.stringify(customers));
      // Display success message (you can use toastr or any other toast library)
      alert('Customer details saved successfully!');
      // Reset the form
      form.resetForm();
    } else {
      console.error('Form is invalid or customer is under 18 years old');
      // Display error message (you can use toastr or any other toast library)
      alert('Please correct the form errors.');
    }
  }

}






