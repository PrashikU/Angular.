import { Component } from '@angular/core';

@Component({
  selector: 'app-assing13',
  templateUrl: './assing13.component.html',
  styleUrl: './assing13.component.scss'
})
export class Assing13Component {

}
