export const environment = {
  prduction:false ,

  test : "This is A Environment",
  version:"V.0.0,1",
  release: "19 , FEB , 20024"
};
