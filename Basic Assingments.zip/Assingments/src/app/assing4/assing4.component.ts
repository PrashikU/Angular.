import { Component } from '@angular/core';

@Component({
  selector: 'app-assing4',
  templateUrl: './assing4.component.html',
  styleUrl: './assing4.component.scss'
})
export class Assing4Component {

}
