import { Component } from '@angular/core';

@Component({
  selector: 'app-assg1',
  templateUrl: './assg1.component.html',
  styleUrl: './assg1.component.scss'
})
export class Assg1Component {
  
}
                                                                                                                              