import { Component } from '@angular/core';
import { book } from './book';



@Component({
  selector: 'app-assing18',
  templateUrl: './assing18.component.html',
  styleUrl: './assing18.component.scss'
})
export class Assing18Component {
 book = book;
}
