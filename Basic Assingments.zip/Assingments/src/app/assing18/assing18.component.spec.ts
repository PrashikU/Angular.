import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing18Component } from './assing18.component';

describe('Assing18Component', () => {
  let component: Assing18Component;
  let fixture: ComponentFixture<Assing18Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing18Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing18Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
