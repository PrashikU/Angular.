import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoggerService {
 //fun create
 
  constructor() { }
  log(msg:any)
  {
    console.log(msg);
  }
}
