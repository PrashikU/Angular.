import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing7Component } from './assing7.component';

describe('Assing7Component', () => {
  let component: Assing7Component;
  let fixture: ComponentFixture<Assing7Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing7Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing7Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
