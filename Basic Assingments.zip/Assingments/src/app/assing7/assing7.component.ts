import { Component } from '@angular/core';
import { LoggerService } from './logger.service';

@Component({
  selector: 'app-assing7',
  templateUrl: './assing7.component.html',
  styleUrl: './assing7.component.scss'
})
export class Assing7Component {
  constructor(private logger:LoggerService)
  
  {
 this.logger.log("Hello from Logger service");
  };

}
