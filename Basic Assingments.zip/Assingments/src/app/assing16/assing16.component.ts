import { Component } from '@angular/core';
import component from '../../../node_modules1/@schematics/angular/component';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-assing16',
  templateUrl: './assing16.component.html',
  styleUrl: './assing16.component.scss'
})
export class Assing16Component {
Num1: number = 0;
Num2: number = 0;
Sum:number = 0;
Show = true;

Add(){
  this.Sum=this.Num1+this.Num2;
  this.Show = false;
}
Reset(){
  this.Num1=0;
  this.Num2=0;
  this.Sum =0;
  this.Show=true;
}
}
