import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing16Component } from './assing16.component';

describe('Assing16Component', () => {
  let component: Assing16Component;
  let fixture: ComponentFixture<Assing16Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing16Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing16Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
