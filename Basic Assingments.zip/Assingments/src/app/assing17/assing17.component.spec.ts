import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing17Component } from './assing17.component';

describe('Assing17Component', () => {
  let component: Assing17Component;
  let fixture: ComponentFixture<Assing17Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing17Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing17Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
