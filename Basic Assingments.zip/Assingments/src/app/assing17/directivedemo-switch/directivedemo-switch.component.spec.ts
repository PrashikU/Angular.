import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DirectivedemoSwitchComponent } from './directivedemo-switch.component';

describe('DirectivedemoSwitchComponent', () => {
  let component: DirectivedemoSwitchComponent;
  let fixture: ComponentFixture<DirectivedemoSwitchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DirectivedemoSwitchComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DirectivedemoSwitchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
