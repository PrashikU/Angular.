import { Component } from '@angular/core';

@Component({
  selector: 'app-directivedemo-switch',
  templateUrl: './directivedemo-switch.component.html',
  styleUrl: './directivedemo-switch.component.scss'
})
export class DirectivedemoSwitchComponent {
Num:number = 0;
check = true;
temp : any;
Num_check()
{
  this.check =false;
  if(this.Num%2===0){
    this.temp = "Even";
  }
  else{
    this.temp = "odd";
  }
}
}
