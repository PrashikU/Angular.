import { Component  } from '@angular/core';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-directivedemo-if',
  templateUrl: './directivedemo-if.component.html',
  styleUrl: './directivedemo-if.component.scss'
})
export class DirectivedemoIfComponent {
Num:any=1;
show:any=true;
num_check(){
 this.show = !this.show;
 
}
}
