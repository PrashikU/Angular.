import { Component } from '@angular/core';

@Component({
  selector: 'app-assing17',
  templateUrl: './assing17.component.html',
  styleUrl: './assing17.component.scss'
})
export class Assing17Component {

}

 