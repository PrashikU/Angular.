import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing5Component } from './assing5.component';

describe('Assing5Component', () => {
  let component: Assing5Component;
  let fixture: ComponentFixture<Assing5Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing5Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
