import { Component } from '@angular/core';

@Component({
  selector: 'app-assing5',
  templateUrl: './assing5.component.html',
  styleUrl: './assing5.component.scss'
})
export class Assing5Component {
  profileimg = "assets/profile.png";
  username = "Prashik";

}
