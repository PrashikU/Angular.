import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing19Component } from './assing19.component';

describe('Assing19Component', () => {
  let component: Assing19Component;
  let fixture: ComponentFixture<Assing19Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing19Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing19Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
