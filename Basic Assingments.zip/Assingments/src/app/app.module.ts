import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { Assg2Component } from './assg2/assg2.component';
import { Assg1Component } from './assg1/assg1.component';
import { Assing3Component } from './assing3/assing3.component';
import { Assing4Component } from './assing4/assing4.component';
import { Assing5Component } from './assing5/assing5.component';
import { Assing6Component } from './assing6/assing6.component';
import { Assing8Component } from './assing8/assing8.component';
import { Assing10Component } from './assing10/assing10.component';
import { FirstComponent } from './assing10/first/first.component';
import { SecondComponent } from './assing10/second/second.component';
import { Assing14Component } from './assing14/assing14.component';
import { Assing9Component } from './assing9/assing9.component';
import { Assing11Component } from './assing11/assing11.component';
import { PageNotFoundComponent } from './assing11/page-not-found/page-not-found.component';
import { Assing15Component } from './assing15/assing15.component';
import { JavaComponent } from './assing15/java/java.component';
import { AngularComponent } from './assing15/angular/angular.component';
import { SqlComponent } from './assing15/sql/sql.component';

import { DemoComponent } from './assing9/demo/demo.component';
import { Assing16Component } from './assing16/assing16.component';
import { FormsModule } from '@angular/forms';
import { Assing17Component } from './assing17/assing17.component';
import { DirectivedemoIfComponent } from './assing17/directivedemo-if/directivedemo-if.component';

//import { DirectivedemoswitchComponent  } from './assing17/directivedemo-if/directivedemo-swich.component';
import { CommonModule } from '@angular/common';
import { DirectivedemoSwitchComponent } from './assing17/directivedemo-switch/directivedemo-switch.component';
import { Assing18Component } from './assing18/assing18.component';
import { Assing12Component } from './assing12/assing12.component';
import { First12Component } from './assing12/first12/first12.component';
import { Second12Component } from './assing12/second12/second12.component';
import { Assing7Component } from './assing7/assing7.component';
import { Assing19Component } from './assing19/assing19.component';
import { BookDetailsComponent } from './assing19/book-details/book-details.component';
import { Assing20Component } from './assing20/assing20.component';
import { Child20Component } from './assing20/child20/child20.component';
import { Assing21Component } from './assing21/assing21.component';
import { Assing22Component } from './assing22/assing22.component';
import { Assing23Component } from './assing23/assing23.component';


DemoComponent

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    Assg2Component,
    Assg1Component,
    Assing3Component,
    Assing4Component,
    Assing5Component,
    Assing6Component,
    Assing8Component,
    Assing10Component,
    FirstComponent,
    SecondComponent,
    Assing14Component,
    Assing9Component,
    Assing11Component,
    PageNotFoundComponent,
    Assing15Component,
    JavaComponent,
    AngularComponent,
    SqlComponent,
  
    DemoComponent,
        Assing16Component,
        Assing17Component,
        DirectivedemoIfComponent,
        DirectivedemoSwitchComponent,
        Assing18Component,
        Assing12Component,
        First12Component,
        Second12Component,
        Assing7Component,
        Assing19Component,
        BookDetailsComponent,
        Assing20Component,
        Child20Component,
        Assing21Component,
        Assing22Component,
        Assing23Component,
        
       

     
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    CommonModule 

  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
