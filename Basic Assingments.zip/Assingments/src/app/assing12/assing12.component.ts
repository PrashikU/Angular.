import { Component } from '@angular/core';

@Component({
  selector: 'app-assing12',
  templateUrl: './assing12.component.html',
  styleUrl: './assing12.component.scss'
})
export class Assing12Component {

}
