import { Component,OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-first12',
  templateUrl: './first12.component.html',
  styleUrl: './first12.component.scss'
})
export class First12Component implements OnInit {
  name:any;
  constructor(private route:ActivatedRoute){}

  ngOnInit(): void {
    this.name= this.route.snapshot.paramMap.get('name');
  }

}
