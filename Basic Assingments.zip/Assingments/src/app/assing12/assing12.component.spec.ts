import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing12Component } from './assing12.component';

describe('Assing12Component', () => {
  let component: Assing12Component;
  let fixture: ComponentFixture<Assing12Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing12Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing12Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
