import { Component,OnInit } from '@angular/core';
import { environment } from '../../environments/environment.development';

@Component({
  selector: 'app-assing8',
  templateUrl: './assing8.component.html',
  styleUrl: './assing8.component.scss'
})
export class Assing8Component implements OnInit{
  show = environment.prduction;
  ngOnInit(): void {
    if(!this.show){
      console.log("Production is Disabled")
    }
  }

}
