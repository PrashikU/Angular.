import { Component } from '@angular/core';
import { environment } from '../../environments/environment.development'; //import

@Component({
  selector: 'app-assing14',
  templateUrl: './assing14.component.html',
  styleUrl: './assing14.component.scss'
})
export class Assing14Component {
  version = environment.version;
  release = environment.release;
}
