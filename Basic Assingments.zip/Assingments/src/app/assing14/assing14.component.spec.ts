import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing14Component } from './assing14.component';

describe('Assing14Component', () => {
  let component: Assing14Component;
  let fixture: ComponentFixture<Assing14Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing14Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing14Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
