import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing22Component } from './assing22.component';

describe('Assing22Component', () => {
  let component: Assing22Component;
  let fixture: ComponentFixture<Assing22Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing22Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing22Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
