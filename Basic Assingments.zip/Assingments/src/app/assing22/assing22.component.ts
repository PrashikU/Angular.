import { Component } from '@angular/core';

@Component({
  selector: 'app-assing22',
  templateUrl: './assing22.component.html',
  styleUrl: './assing22.component.scss'
})
export class Assing22Component {
  rows: number = 0;
  pyramidRows: string[] = [];

  generatePyramid() {
    this.pyramidRows = [];
    let rowString = '';
    for (let i = 1; i <= this.rows; i++) {
      rowString = '';
      
      for (let op = this.rows-i; op >0; op--) {
        rowString += ' ';
      }

      for (let j = 1; j <= (2 * i - 1); j++) {
        rowString += '* ';
      }
      this.pyramidRows.push(rowString);
    }
  } 

}
