import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Assing13Component } from './assing13.component';

const routes: Routes = [{ path: '', component: Assing13Component }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class Assing13RoutingModule {}
