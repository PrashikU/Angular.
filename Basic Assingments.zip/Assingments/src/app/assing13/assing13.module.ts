import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Assing13RoutingModule } from './assing13-routing.module';
import { Assing13Component } from './assing13.component';


@NgModule({
  declarations: [
    Assing13Component
  ],
  imports: [
    CommonModule,
    Assing13RoutingModule
  ]
})
export class Assing13Module { }
