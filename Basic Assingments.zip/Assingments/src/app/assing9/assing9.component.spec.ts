import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing9Component } from './assing9.component';

describe('Assing9Component', () => {
  let component: Assing9Component;
  let fixture: ComponentFixture<Assing9Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing9Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing9Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
