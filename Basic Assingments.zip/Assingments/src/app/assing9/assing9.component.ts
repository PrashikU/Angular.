import { Component } from '@angular/core';

@Component({
  selector: 'app-assing9',
  templateUrl: './assing9.component.html',
  styleUrl: './assing9.component.scss'
})
export class Assing9Component {

}
