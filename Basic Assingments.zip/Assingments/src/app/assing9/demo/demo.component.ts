import { Component, OnInit, OnChanges, AfterViewInit, OnDestroy, Input, SimpleChanges, DoCheck } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrl: './demo.component.scss'
})
export class DemoComponent implements OnInit, OnChanges,DoCheck, AfterViewInit, OnDestroy {
  @Input() name: any;

  constructor() {
    console.log("constructor is called");

   }

  ngOnInit(): void {
    console.log("OnInit is called");
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log("OnChanges is called");
  }
ngDoCheck(): void {
  console.log("Docheck is called");
}
  ngAfterViewInit(): void {
    console.log("AfterViewInit is called");
  }

  ngOnDestroy(): void {
    console.log("OnDestroy is called");
  }

}

