import { Component } from '@angular/core';

@Component({
  selector: 'app-assing3',
  templateUrl: './assing3.component.html',
  styleUrl: './assing3.component.scss'
})
export class Assing3Component {

}
