import { Component } from '@angular/core';

@Component({
  selector: 'app-assing21',
  templateUrl: './assing21.component.html',
  styleUrl: './assing21.component.scss'
})
export class Assing21Component {
  input_year:any;
  Leap : any;
  Days : any;
  Holidays : any;
  show:any = false;

  calculate()
  {
    this.isLeap();
    this.total_days();
    this.total_holidays();
    this.show =true;

  }

  isLeap() 
  {
    if(this.input_year %400==0)
      {
      this.Leap = "Yes";
      }

    else
    {
      if(this.input_year % 4 === 0 && this.input_year %100 !==0)
      {
       this.Leap = "Yes";
      }
      else
      {
       this.Leap = "No";
      }
    }
  }
  total_days()
  {
    if(this.Leap=="Yes")
      this.Days = 366;
    else
    this.Days = 365;
  }

  total_holidays()
  {
    this.Holidays = 104;
  }

}