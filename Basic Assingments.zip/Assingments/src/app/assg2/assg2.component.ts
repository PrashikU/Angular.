import { Component } from '@angular/core';

@Component({
  selector: 'app-assg2',
  template: '<div><h1><p>Prashik Unawane</p></h1></div>',
  styleUrl: './assg2.component.scss'
})
export class Assg2Component {

}
