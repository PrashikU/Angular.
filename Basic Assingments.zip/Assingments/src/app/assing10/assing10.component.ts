import { Component } from '@angular/core';

@Component({
  selector: 'app-assing10',
  templateUrl: './assing10.component.html',
  styleUrl: './assing10.component.scss'
})
export class Assing10Component {

}
