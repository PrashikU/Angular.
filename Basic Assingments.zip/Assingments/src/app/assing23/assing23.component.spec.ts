import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing23Component } from './assing23.component';

describe('Assing23Component', () => {
  let component: Assing23Component;
  let fixture: ComponentFixture<Assing23Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing23Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing23Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
