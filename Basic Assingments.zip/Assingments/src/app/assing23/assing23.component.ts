import { Component } from '@angular/core';

@Component({
  selector: 'app-assing23',
  templateUrl: './assing23.component.html',
  styleUrl: './assing23.component.scss'
})
export class Assing23Component {
 current_date=new Date();
 str = "Prashik";
 num = 16.68;
 
}
 