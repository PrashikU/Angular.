import { Component } from '@angular/core';

@Component({
  selector: 'app-assing6',
  templateUrl: './assing6.component.html',
  styleUrl: './assing6.component.scss'
})
export class Assing6Component {
imgPath="";
  displayProfile()
  {
    this.imgPath = "assets/profile.png";
  }
}
