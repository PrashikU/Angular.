import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing6Component } from './assing6.component';

describe('Assing6Component', () => {
  let component: Assing6Component;
  let fixture: ComponentFixture<Assing6Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing6Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
