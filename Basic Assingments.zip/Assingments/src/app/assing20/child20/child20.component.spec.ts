import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Child20Component } from './child20.component';

describe('Child20Component', () => {
  let component: Child20Component;
  let fixture: ComponentFixture<Child20Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Child20Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Child20Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
