import { Component , Input, Output , EventEmitter} from '@angular/core';
import { log } from 'console';

@Component({
  selector: 'app-child20',
  templateUrl: './child20.component.html',
  styleUrl: './child20.component.scss'
})
export class Child20Component {
@Input() book:any;
@Output() t1=new EventEmitter<string>();
@Output() t2=new EventEmitter<number>();
num:number=0;

rateBook(val:any){
this.t1.emit(val );
this.t2.emit(Math.floor(Math.random()*10));

}


}
 