import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing20Component } from './assing20.component';

describe('Assing20Component', () => {
  let component: Assing20Component;
  let fixture: ComponentFixture<Assing20Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing20Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing20Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
