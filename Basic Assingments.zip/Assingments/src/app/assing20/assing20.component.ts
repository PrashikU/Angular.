import { Component,OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-assing20',
  templateUrl: './assing20.component.html',
  styleUrl: './assing20.component.scss'
})
export class Assing20Component {
  books =      [{
    title: "book1",
    description: "book desc 1"
  },{
    title: "book2",
    description: "book desc 2"
  },{ 
    title: "book3",
    description: "book desc 3"
  },{
    title: "book4",
    description: "book desc 4 "
  }];

  tle:string='';
  rat :number=0;
read1(val:string)
{
this.tle=val;
}
read2(val:number)
{
this.rat=val;
alert("rating of "+ this.tle+" is "+this.rat)
}

}
