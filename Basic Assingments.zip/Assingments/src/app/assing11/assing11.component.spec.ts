import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing11Component } from './assing11.component';

describe('Assing11Component', () => {
  let component: Assing11Component;
  let fixture: ComponentFixture<Assing11Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing11Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing11Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
