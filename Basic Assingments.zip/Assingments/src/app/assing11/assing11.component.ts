import { Component } from '@angular/core';

@Component({
  selector: 'app-assing11',
  templateUrl: './assing11.component.html',
  styleUrl: './assing11.component.scss'
})
export class Assing11Component {

}
