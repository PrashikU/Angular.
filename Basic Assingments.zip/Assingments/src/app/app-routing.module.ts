import { SecondComponent } from './assing10/second/second.component';
import { Assing8Component } from './assing8/assing8.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Assg1Component } from './assg1/assg1.component';
import { Assg2Component } from './assg2/assg2.component';
import { Assing3Component } from './assing3/assing3.component';
import { Assing4Component } from './assing4/assing4.component';
import { Assing5Component } from './assing5/assing5.component';
import { Assing6Component } from './assing6/assing6.component';
import { Assing10Component } from './assing10/assing10.component';
import { FirstComponent } from './assing10/first/first.component';
import { Assing14Component } from './assing14/assing14.component';
import { Assing9Component } from './assing9/assing9.component';
import { Assing11Component } from './assing11/assing11.component';
import { PageNotFoundComponent } from './assing11/page-not-found/page-not-found.component';
import { Assing15Component } from './assing15/assing15.component';
import { AngularComponent } from './assing15/angular/angular.component';
import { JavaComponent } from './assing15/java/java.component';
import { SqlComponent } from './assing15/sql/sql.component';
import { Assing16Component } from './assing16/assing16.component';
import { Assing17Component } from './assing17/assing17.component';
import { DirectivedemoIfComponent } from './assing17/directivedemo-if/directivedemo-if.component';
import { DirectivedemoSwitchComponent } from './assing17/directivedemo-switch/directivedemo-switch.component';
import { Assing18Component } from './assing18/assing18.component';
import { Assing12Component } from './assing12/assing12.component';
import { First12Component } from './assing12/first12/first12.component';
import { Second12Component } from './assing12/second12/second12.component';
import { Assing7Component } from './assing7/assing7.component';
import { Assing19Component } from './assing19/assing19.component';
import { Assing20Component } from './assing20/assing20.component';
import { Assing21Component } from './assing21/assing21.component';
import { Assing22Component } from './assing22/assing22.component';
import { Assing23Component } from './assing23/assing23.component';

// import { DirectivedemoSwichComponent } from './assing17/directivedemo-swich/directivedemo-swich.component';
// import { Assing13Module } from './assing13/assing13.module';

const routes: Routes = [

  {path: 'assg1',component:Assg1Component },
  {path: 'assg2',component:Assg2Component},
  {path: 'assing3',component:Assing3Component},
  {path: 'assing4',component:Assing4Component},
  {path: 'assing5',component:Assing5Component},
  {path: 'assing6',component:Assing6Component},
  {path:'assing7',component:Assing7Component},
  {path: 'assing8',component:Assing8Component},
  {path:'assing9',component:Assing9Component},
  {path: 'assing10',component:Assing10Component},
  {path: 'first',component:FirstComponent},
  {path: 'second',component:SecondComponent},
  {path: 'assing11',component:Assing11Component},
 
  {path: 'assing14',component:Assing14Component},
  {path:'assing15',component:Assing15Component},
  {path:'angular',component:AngularComponent},
  {path:'java',component:JavaComponent},
  {path:'sql',component:SqlComponent},
  {path:'assing16',component:Assing16Component},
  {path:'assing17',component:Assing17Component},
  {path:"ngIf",component:DirectivedemoIfComponent},
  {path:"ngSwitch",component: DirectivedemoSwitchComponent},
  {path:"assing18",component:Assing18Component},
  {path:"assing12",component:Assing12Component},
  {path:"first12/:name",component:First12Component},
  {path:"second12/:id",component:Second12Component},
  {path:"assing19",component:Assing19Component},
  {path:"assing20",component:Assing20Component},
  {path:"assing21",component:Assing21Component},
  {path:"assing22",component:Assing22Component},
  {path:"assing23",component:Assing23Component},
  
  { path: 'assing13', loadChildren: () => import('./assing13/assing13.module').then(m => m.Assing13Module) }, //for difalt
  {path:"",redirectTo:'assg1',pathMatch:'full'},
  {path:"**",component:PageNotFoundComponent}, // page notf found
  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
