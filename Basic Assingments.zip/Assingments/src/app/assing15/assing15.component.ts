import { Component } from '@angular/core';

@Component({
  selector: 'app-assing15',
  templateUrl: './assing15.component.html',
  styleUrl: './assing15.component.scss'
})
export class Assing15Component {

}
