import { Component } from '@angular/core';

@Component({
  selector: 'app-java',
  templateUrl: './java.component.html',
  styleUrl: './java.component.scss'
})
export class JavaComponent {

}
