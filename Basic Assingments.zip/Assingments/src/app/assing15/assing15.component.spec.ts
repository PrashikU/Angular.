import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assing15Component } from './assing15.component';

describe('Assing15Component', () => {
  let component: Assing15Component;
  let fixture: ComponentFixture<Assing15Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Assing15Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Assing15Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
